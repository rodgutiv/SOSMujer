Esta carpeta contiene los archivos de la App Móvil del proyecto.
