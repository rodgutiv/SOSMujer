Ésta carpeta contiene los archivos de la Aplicación Web de Escritorio del proyecto, para su uso en las oficinas de la Policía Municipal.
